<?php require_once("assets/config/config.php"); ?>
<!DOCTYPE html>
<!--[if lt IE 7]>   <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="es"> <![endif]-->
<!--[if IE 7]> 		<html class="no-js lt-ie9 lt-ie8" lang="es"> <![endif]-->
<!--[if IE 8]> 		<html class="ie8 no-js" lang="es"> <![endif]-->
<!--[if IE 9]> 		<html class="ie9 no-js" lang="es"> <![endif]-->
<!--[if !IE]><!-->
<html lang="es">
<!--<![endif]-->

<head>
     <meta charset="utf-8">
     <meta name="author" content="Luis Óscar Bueno Sánchez">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="description" content="Tarea 30 del 11">
     <title>Analytics — Landing Page</title>
     <link rel="stylesheet" href="assets/css/main.css" type="text/css" />

</head>

<body>
     <?php include("assets/templates/header.php"); ?>
     <main>
          <section class="section-1">
               <h2>Main Features</h2>
               <p>Lorem ipsum dolor si amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet. Id vel in nam malesuada.</p>
               <div class="cards">
                    <div>
                         <img src="assets\images\planning.png" alt="Icono planning">
                         <h3>Monitoring 24/7</h3>
                         <p>Lorem ipsum dolor sit amet, consectetur adipis cing elit. Elementum nisi aliquet volutpat.</p>
                    </div>
                    <div>
                         <img src="assets\images\computer.png" alt="Icono computer">
                         <h3>Widget System</h3>
                         <p>Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar.</p>
                    </div>
                    <div>
                         <img src="assets\images\speed.png" alt="Icono speed">
                         <h3>Best Performance</h3>
                         <p>Lorem ipsum dolor sit amet, consectetur adipis cing elit. Elementum nisi aliquet volutpat.</p>
                    </div>
               </div>
          </section>
          <section class="section-2">
               <div class="texto">
                    <h2>Automated Reports & Widget Alerts</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
               <img src="assets\images\screen-01.svg" alt="" srcset="">
          </section>
          <section class="section-2">
               <img src="assets\images\screen-02.svg" alt="" srcset="">
               <div class="texto">
                    <h2>Fully customizable to address your needs</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
          </section>
          <section class="section-2">
               <div class="texto">
                    <h2>Pre-built Dashboard Templates</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
               <img src="assets\images\screen-03.svg" alt="" srcset="">
          </section>
          
     </main>
     <?php include("assets/templates/footer.php"); ?>
     <script src="assets/js/custom.js"></script>
</body>
</html>