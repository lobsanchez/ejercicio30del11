<header>

        <div class="logo">
            <img src="assets\images\logo.png" alt="">
        </div>
        <nav>
            <ul>
                <li><a href="#">Products</a></li>
                <li><a href="#">Pricing</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Blog</a></li>
            </ul>
        </nav>
        <div class="nav-right">
            <button class="no-border">Sign in</button>
            <button class="border">Sign Up</button>
        </div>
        
        <div class="title-hero">
            <h1>Monitor your business on real-time dashboard</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. </p>
            <button class="pink">Try for free</button>
        </div>
        <div class="img-hero">
           <img src="assets\images\main-screenDoble.svg" alt="Imagen doble">
        </div>
        
    
</header>

